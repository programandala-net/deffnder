#!/bin/bash
#
# :dbolli:20121201 19:14:46 zmakebas ZX BASIC Compiler

#ZASMLOCATION=~/Applications/zasm-cocoa/bin			# :dbolli:20150115 11:06:29 zasm v3.x
ZASMLOCATION=~/dev/unix-src/zasm-4.0/bin			# :dbolli:20150117 22:24:12 zasm v4.x
#ZASMOPTIONS=-vw2									# :dbolli:20150115 11:06:29 zasm v3.x
ZASMOPTIONS="-uwv2"									# :dbolli:20150115 11:06:29 zasm v4.x add y for opcode timings

z88dkpathinitialised=`echo $PATH | grep 'z88dk'`
if [ "$z88dkpathinitialised" == "" ]
then
    # :dbolli:20121201 19:14:46 z88dk Z80 Development Kit
    PATH=$PATH:~/dev/unix-src/z88dk/bin/:/usr/local/bin/
    export PATH				# :dbolli:20141219 10:02:58 For z88dk tapmaker
fi

ZMAKEBASLOCATION=~/dev/unix-src/zmakebas-1.5

Z80EXECNAME=deffnder-demo

cd ~/dev/Z80\ src/deffnder-pasmo/demo/

$ZMAKEBASLOCATION/zmakebas -i 10 -a 10 -l -o $Z80EXECNAME.tap -n $Z80EXECNAME "$Z80EXECNAME".bas

tapfilecreated=`find ./$Z80EXECNAME.tap -type f -ctime -5s | grep $Z80EXECNAME.tap`
#echo $tapfilecreated		# DEBUG
if [ "$tapfilecreated" != "" ]
then
	$ZASMLOCATION/zasm $ZASMOPTIONS "$Z80EXECNAME-zasm.asm" -o "$Z80EXECNAME.bin" -l "$Z80EXECNAME-zasm.lis"
	
	tapmaker $Z80EXECNAME.bin $Z80EXECNAME.tap 61440
	
	cat $Z80EXECNAME.tap ../bin/deffnder.tap > $Z80EXECNAME-tap.tap
	
	rm $Z80EXECNAME.tap
#	cp $Z80EXECNAME-tap.tap $Z80EXECNAME.tap
    mv $Z80EXECNAME-tap.tap $Z80EXECNAME.tap

#	rm $Z80EXECNAME-tap.tap

	open $Z80EXECNAME.tap
fi