#!/bin/bash
#
# :dbolli:20121201 19:14:46 zmakebas ZX BASIC Compiler

z88dkpathinitialised=`echo $PATH | grep 'z88dk'`
if [ "$z88dkpathinitialised" == "" ]
then
    # :dbolli:20121201 19:14:46 z88dk Z80 Development Kit
    PATH=$PATH:~/dev/unix-src/z88dk/bin/:/usr/local/bin/
    export PATH				# :dbolli:20141219 10:02:58 For z88dk tapmaker
fi

ZMAKEBASLOCATION=~/dev/unix-src/zmakebas-1.5

Z80EXECNAME=deffnder-demo

cd ~/dev/Z80\ src/deffnder-pasmo/demo/

$ZMAKEBASLOCATION/zmakebas -i 10 -a 10 -l -o $Z80EXECNAME.tap -n $Z80EXECNAME "$Z80EXECNAME".bas

tapfilecreated=`find ./$Z80EXECNAME.tap -type f -ctime -5s | grep $Z80EXECNAME.tap`
#echo $tapfilecreated		# DEBUG
if [ "$tapfilecreated" != "" ]
then
	pasmo -v -1 --bin "$Z80EXECNAME-pasmo.asm" "$Z80EXECNAME.bin" > "$Z80EXECNAME-pasmo.lis"
	
	tapmaker $Z80EXECNAME.bin $Z80EXECNAME.tap 61440
	
	cat $Z80EXECNAME.tap ../bin/deffnder.tap > $Z80EXECNAME-tap.tap
	
	rm $Z80EXECNAME.tap
#	cp $Z80EXECNAME-tap.tap $Z80EXECNAME.tap
	mv $Z80EXECNAME-tap.tap $Z80EXECNAME.tap

#	rm $Z80EXECNAME-tap.tap
	
	open $Z80EXECNAME.tap
fi